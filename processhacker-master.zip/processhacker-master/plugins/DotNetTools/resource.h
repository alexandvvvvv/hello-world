//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DotNetTools.rc
//
#define IDD_PROCDOTNETPERF              101
#define IDD_PROCDOTNETASM               102
#define ID_CLR_OPENFILELOCATION         103
#define ID_CLR_COPY                     104
#define ID_CLR_INSPECT                  105
#define ID_COPY                         106
#define IDC_OPTIONS                     1002
#define IDC_COUNTERS                    1003
#define IDC_REFRESH                     1003
#define IDC_LIST                        1005
#define IDC_SEARCHEDIT                  1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
